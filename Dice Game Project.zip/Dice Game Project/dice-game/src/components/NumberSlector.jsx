import { useState } from "react";
import styled from "styled-components"

const NumberSlector = ({setError, error , selectedNo , setSlectedNo}) => {

     console.log(selectedNo)
     const noSelectorHandler = (value)=>{
           setSlectedNo(value);
           setError("")
     }

     

      const array=[1,2,3,4,5,6];
  return (
       
        <NoSelectorContainer>
        <p className="pra"> {error} </p>

    <div className="flex">
     {array.map((value,i)=>  (<Box
     isSlected={value === selectedNo} 
     key={i} onClick={()=>noSelectorHandler(value)}> {value} </Box>))}
     </div>
     <p> Select Number</p>
    </NoSelectorContainer>
        
    
  )
}

export default NumberSlector

const  NoSelectorContainer = styled.div`

        display: flex;
        flex-direction: column;
        align-items: end;
        white-space: nowrap;
       
       
       .flex{
        display: flex;
        gap: 15px;
         
       }
       p{
        font-size: 24px;
        font-weight: 400;
       }
       .pra{
        font-size: 15px;
         font-weight: 400;
         color: red;
       }
      
`;

const Box = styled.div`
      height: 40px;
      width: 40px;
      border: none;
      display: grid;
      place-items: center;
      font-size: 20px;
      font-weight: 400;
      cursor: pointer;
      background-color: ${(props) => (props.isSlected ? "black" : "lightgray")};
      color: ${(props) => (!props.isSlected ? "black" : "white")};


.box{
    display: inline;
}
`;
