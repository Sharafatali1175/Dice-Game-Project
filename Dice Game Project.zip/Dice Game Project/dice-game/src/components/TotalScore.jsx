
import styled from 'styled-components'

const TotalScore = ({score}) => {
  return (
    
      <ScoreContainer> <h1> {score} </h1>
         <p> Total Score </p>
      </ScoreContainer>
  )
}

export default TotalScore

const ScoreContainer = styled.div`
     max-width: 800px;
     text-align: center;
    
 h1{
    font-size: 50px;
    line-height: 40px;
    }
 p{
    font-size: 24px;
    font-weight: 800;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.79);
 }

`;
