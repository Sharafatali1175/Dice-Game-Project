import styled from "styled-components"
import dice_1 from '../images/dice/dice_1.png';
import dice_2 from '../images/dice/dice_2.png';
import dice_3 from '../images/dice/dice_3.png';
import dice_4 from '../images/dice/dice_4.png';
import dice_5 from '../images/dice/dice_5.png';
import dice_6 from '../images/dice/dice_6.png';


const RoleDice = ({rollDice, currentDice}) => {
  const diceImages = [dice_1, dice_2, dice_3, dice_4, dice_5, dice_6];

  return (
    <DiceContainer>
      <div className="dice" onClick={rollDice}>
        <img src={diceImages[currentDice - 1]} alt={`dice-${currentDice}`} />
      </div>
      <p>Click on Dice to roll</p>
    </DiceContainer>
  );
};

export default RoleDice;

const DiceContainer = styled.div`
  margin-top: 48px;
  display: flex;
  flex-direction: column;
  align-items: center;

  .dice {
    cursor: pointer;
  }

  p {
    font-size: 20px;
    font-weight: 500;
    color: blue;
   
  }
  .dice img{ width:150px}
`;
