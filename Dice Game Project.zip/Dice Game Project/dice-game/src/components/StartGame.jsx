
import styled from "styled-components";
import dices from "../images/dices.png";
import { Button } from "../styled/Button";
const StartGame = ({toggle}) => {
  return ( <Container>
             <div>  <img src={dices} alt='...' /> </div>
            <div className="content">
            <h1> Dice Game </h1>
            <Button className="btn" onClick={toggle}> Play Now </Button>
         </div>
  
   </Container>
)}

export default StartGame;

const Container = styled.div`
max-width: 1180px;
height: 95vh;
display: flex;
margin:  auto;
justify-content: center;
align-items: center;
gap:5px;

.content{
    h1{
        font-size: 70px;
        white-space: nowrap;
        text-shadow: 2px 2px 4px rgba(121, 32, 179, 0.5);
        padding-right: 50px;
    
    }
}
.btn{
    background-color: blue;
    margin-left: 50px;
    font-weight:bold;
}
`;
