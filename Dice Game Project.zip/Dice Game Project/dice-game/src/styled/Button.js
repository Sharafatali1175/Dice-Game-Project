import styled from "styled-components";

export const Button = styled.button`
min-width: 300px;
padding: 8px 15px;
color: white;
border: none;
background-color: #000000;
border-radius: 5px;
font-size: 16px;
border: 1px solid transparent;
margin-top:8px;
cursor: pointer;
box-shadow: 0 4px 6px rgba(11, 11, 11, 0.3);
transition: background-color 0.5s ease, transform 0.3s ease;
&:hover{
    background-color: white;
    border: 1px solid black;
    color: black;
    transition: background-color 0.5s ease, transform 0.3s ease-in;
   
}
`;
export const OutlineButton = styled(Button)`
    background-color: white;
    border: 1px solid black;
    color: black;
   &:hover{
    background-color: black;
    border: 1px solid transparent;
    color: white;
   
}

`;
