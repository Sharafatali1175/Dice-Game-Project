
import { useState } from 'react';
import './App.css';
import StartGame from './components/StartGame';
import GamePlay from './components/GamePlay';


function App() {
 
  const [gameStart,setGameStart] = useState(false)

  const toggleGamePlay = ()=>{
       setGameStart((pre)=> !pre)
  }

  return (
    <>
     {gameStart ? <GamePlay/> :<StartGame toggle={toggleGamePlay}/>}
    
     
      
       
    </>
  )
}

export default App


